// Function to toggle login form visibility
function toggleLoginForm() {
    var loginForm = document.getElementById("loginForm");
    var signupForm = document.getElementById("signupForm");
    
    loginForm.style.display = "block"; // Display login form
    signupForm.style.display = "none"; // Hide sign up form
}

// Function to toggle sign-up form visibility
function toggleSignUpForm() {
    var loginForm = document.getElementById("loginForm");
    var signupForm = document.getElementById("signupForm");
    
    loginForm.style.display = "none"; // Hide login form
    signupForm.style.display = "block"; // Display sign up form
}

// Function to close login form
function closeLoginForm() {
    var loginForm = document.getElementById("loginForm");
    loginForm.style.display = "none"; // Hide login form
}

// Function to close sign-up form
function closeSignUpForm() {
    var signUpForm = document.getElementById("signupForm");
    signUpForm.style.display = "none"; // Hide sign up form
}

// Function to redirect to the landing page (main page)
function redirectToLandingPage() {
    window.location.href = "index.html"; // Redirect to the main page
}

// Function to redirect to the user profile page
function redirectToProfilePage() {
    window.location.href = "profile.html"; // Redirect to the user profile page
}

// Example function for handling successful login (you may already have this)
function handleSuccessfulLogin() {
    // Perform login validation/authentication

    // If login is successful, redirect to profile page
    redirectToProfilePage();
}

// Add event listener to the "Home" button
document.getElementById("homeBtn").addEventListener("click", redirectToLandingPage);
// Function to handle login form submission
function handleLogin(event) {
    event.preventDefault(); // Prevent default form submission
    // Your login validation/authentication code here

    // If login is successful, call the redirectToProfilePage function
    redirectToProfilePage();
}

// Function to handle signup form submission
function handleSignup(event) {
    event.preventDefault(); // Prevent default form submission
    // Your signup validation/authentication code here

    // If signup is successful, call the redirectToProfilePage function
    redirectToProfilePage();
}
// Function to redirect to the cover letter page
function redirectToCoverLetterPage() {
    window.location.href = "cover_letter.html"; // Redirect to the cover letter page
}
// Function to redirect to the dashboars
function redirectToDashBoard() {
    window.location.href = "profile.html";
}
